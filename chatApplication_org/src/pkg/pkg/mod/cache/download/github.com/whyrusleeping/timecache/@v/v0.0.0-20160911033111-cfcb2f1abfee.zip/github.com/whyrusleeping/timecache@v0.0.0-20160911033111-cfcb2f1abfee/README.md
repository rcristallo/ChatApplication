# timecache

Timecache is an lru cache that keeps entries for up to a specified time
duration. After a specified period of time has elapsed, 'old' entries will be
purged from the set.

## License
MIT
