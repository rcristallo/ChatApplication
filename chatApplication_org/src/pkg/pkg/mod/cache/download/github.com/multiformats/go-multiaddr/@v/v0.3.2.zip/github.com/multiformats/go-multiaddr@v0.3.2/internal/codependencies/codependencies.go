package codependencies

import (
	// Packages imported into this package.

	// go-maddr-filter < 0.1.0 conflicts with this package.
	_ "github.com/libp2p/go-maddr-filter"
)
