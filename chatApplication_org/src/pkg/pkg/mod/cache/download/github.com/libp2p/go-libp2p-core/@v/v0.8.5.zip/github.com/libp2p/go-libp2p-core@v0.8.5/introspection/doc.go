// Package introspection is EXPERIMENTAL. It is subject to heavy change, and it
// WILL change. For now, it is the simplest implementation to power the
// proof-of-concept of the libp2p introspection framework.
//
// Package introspect contains the abstract skeleton of the introspection system
// of go-libp2p, and holds the introspection data schema.
package introspection
