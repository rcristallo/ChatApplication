go-libp2p-pnet
==================

[![](https://img.shields.io/badge/made%20by-Protocol%20Labs-blue.svg?style=flat-square)](https://protocol.ai)
[![](https://img.shields.io/badge/project-libp2p-yellow.svg?style=flat-square)](https://libp2p.io/)
[![](https://img.shields.io/badge/freenode-%23libp2p-yellow.svg?style=flat-square)](http://webchat.freenode.net/?channels=%23libp2p)
[![Travis CI](https://img.shields.io/travis/libp2p/go-libp2p-pnet.svg?style=flat-square&branch=master)](https://travis-ci.org/libp2p/go-libp2p-pnet)
[![codecov.io](https://img.shields.io/codecov/c/github/libp2p/go-libp2p-pnet.svg?style=flat-square&branch=master)](https://codecov.io/github/libp2p/go-libp2p-pnet?branch=master)
[![Discourse posts](https://img.shields.io/discourse/https/discuss.libp2p.io/posts.svg)](https://discuss.libp2p.io)

> An implementation of go-libp2p-interface-pnet


## Table of Contents

- [Usage](#usage)
- [Contribute](#contribute)
- [License](#license)

## Usage

See [Godocs](https://godoc.org/github.com/libp2p/go-libp2p-pnet)

## Contribute

PRs are welcome!

Small note: If editing the Readme, please conform to the [standard-readme](https://github.com/RichardLitt/standard-readme) specification.

## License

MIT © Jakub Sztandera

---

The last gx published version of this module was: 3.0.5: QmTwDsJUPioMKoiuXkAmiPxL1i4tjuG5vkxJgNpiHpXb3Y
