package internal

import "errors"

var ErrInvalidRecord = errors.New("received invalid record")
