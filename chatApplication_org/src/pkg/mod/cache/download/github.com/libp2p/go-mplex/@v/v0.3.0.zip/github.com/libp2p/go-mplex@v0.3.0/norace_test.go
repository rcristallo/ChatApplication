//+build !race

package multiplex

var raceEnabled = false
