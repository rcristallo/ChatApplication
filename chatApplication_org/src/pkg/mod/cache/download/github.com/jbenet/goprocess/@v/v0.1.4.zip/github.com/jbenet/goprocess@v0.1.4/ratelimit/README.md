# goprocess/ratelimit - ratelimit children creation

- goprocess: https://github.com/jbenet/goprocess
- Godoc: https://godoc.org/github.com/jbenet/goprocess/ratelimit
