# go-keyspace
This is a package extracted from go-ipfs.

Its purpose it to be used to compare a set of keys based on a given
metric. The primary metric used is XOR, as in kademlia.

