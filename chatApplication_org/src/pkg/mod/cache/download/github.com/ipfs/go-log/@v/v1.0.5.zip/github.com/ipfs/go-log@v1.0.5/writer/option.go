package log

// WriterGroup is the global writer group for logs to output to
var WriterGroup = NewMirrorWriter()
