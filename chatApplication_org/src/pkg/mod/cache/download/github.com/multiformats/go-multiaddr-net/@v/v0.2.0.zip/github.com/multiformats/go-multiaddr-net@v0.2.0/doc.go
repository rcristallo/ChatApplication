// Deprecated: use github.com/multiformats/go-multiaddr/net
package manet
